// src/App.js
import React from 'react';
import './App.css';
import Translate from './Translate';

function App() {
  return (
    <div className="App">
      <Translate />
    </div>
  );
}

export default App;
