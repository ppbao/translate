// src/Translate.js
import React, { useState } from 'react';
import axios from 'axios';

const Translate = () => {
  const [text, setText] = useState('');
  const [translation, setTranslation] = useState('');
  const apiKey = 'ec4db637d8mshad875bcd9978c89p12f838jsn933c33b6a5cc';

  const handleTranslate = async () => {
    try {
      const response = await axios.post(
        'https://google-translate113.p.rapidapi.com/api/v1/translator/text',
        {
          text,
          target: 'en', // Target language code (e.g., 'en' for English)
        },
        {
          headers: {
            'x-rapidapi-key': apiKey,
            'x-rapidapi-host': 'google-translate113.p.rapidapi.com', // Hostname provided by RapidAPI
          },
        }
      );
      setTranslation(response.data.translation);
      console.log(translation)
    } catch (error) {
      console.error('Error translating text:', error);
    }
  };
 

  return (
    <div>
      <h1>Translate Text</h1>
      <textarea
        rows="4"
        cols="50"
        value={text}
        onChange={(e) => setText(e.target.value)}
        placeholder="Enter text to translate"
      />
      <button onClick={handleTranslate}>Translate</button>
      
      {translation && <div>Translation: {translation}</div>}
    </div>
  );
};

export default Translate;
